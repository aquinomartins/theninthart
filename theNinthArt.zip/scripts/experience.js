import { assets } from './modules/asset-manifest.js';
import { createDetailCarousel } from './modules/carousel.js';
import { initScrollScenes } from './modules/scroll-scenes.js';
import { initAdminPanel } from './modules/admin-panel.js';
import { createSession, updateSession, localPersistence } from './modules/state-store.js';
import { createPublicSnapshot } from './modules/public-state.js';
import { getDominantEra } from './modules/temporal-engine.js';

const qs = (selector, root = document) => root.querySelector(selector);
const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];
let initializationPromise = null;
let globalEventsBound = false;

class ExperienceResourceError extends Error {
  constructor({ resourceId, resourceType, url = null, status = null, statusText = '', contentType = '', essential = false, cause = null, message }) {
    super(message, { cause });
    this.name = 'ExperienceResourceError';
    this.resourceId = resourceId;
    this.resourceType = resourceType;
    this.url = url;
    this.status = status;
    this.statusText = statusText;
    this.contentType = contentType;
    this.essential = essential;
  }
}

async function loadJson(path) {
  const url = new URL(path, document.baseURI);
  let response;
  try {
    response = await fetch(url);
  } catch (error) {
    throw new ExperienceResourceError({
      resourceId: path,
      resourceType: 'json',
      url: url.href,
      essential: true,
      cause: error,
      message: `Falha de rede ao carregar ${url.pathname}`
    });
  }
  const contentType = response.headers.get('content-type') || '';
  if (!response.ok) {
    throw new ExperienceResourceError({
      resourceId: path,
      resourceType: 'json',
      url: url.href,
      status: response.status,
      statusText: response.statusText,
      contentType,
      essential: true,
      message: `Falha ao carregar ${url.pathname}: ${response.status} ${response.statusText}`
    });
  }
  if (!contentType.includes('application/json')) {
    const preview = await response.text();
    throw new ExperienceResourceError({
      resourceId: path,
      resourceType: 'json',
      url: url.href,
      status: response.status,
      statusText: response.statusText,
      contentType,
      essential: true,
      message: `Esperado JSON em ${url.pathname}, mas foi recebido ${contentType}. Início da resposta: ${preview.slice(0, 120)}`
    });
  }
  try {
    return await response.json();
  } catch (error) {
    throw new ExperienceResourceError({
      resourceId: path,
      resourceType: 'json',
      url: url.href,
      status: response.status,
      statusText: response.statusText,
      contentType,
      essential: true,
      cause: error,
      message: `JSON inválido em ${url.pathname}`
    });
  }
}

async function boot() {
  hydrateAssetImages();
  initFloatingNarrative();
  initScrollScenes();
  const dataset = { eras: await loadJson('data/eras.json'), parts: await loadJson('data/machine-parts.json'), objects: await loadJson('data/visual-objects.json'), panels: await loadJson('data/story-panels.json') };
  let publicSnapshot = await localPersistence.loadPublicSnapshot() || createPublicSnapshot(await localPersistence.loadSessions(), dataset.eras);
  let session = restoreFromUrl(dataset) || await localPersistence.loadCurrentSession() || createSession(dataset);
  const credentialRecord = await localPersistence.loadCredentialStatus();
  session = updateSession(session, dataset, { credentialStatus: credentialRecord?.status || session.credentialStatus || null });

  async function persistAndRender() { await localPersistence.saveSession(session); updateUrl(session); renderAll(); }
  function renderAll() {
    const dominant = getDominantEra(session.vector, dataset.eras);
    document.documentElement.style.setProperty('--temporal-accent', dataset.parts.find((part) => session.selectedParts.includes(part.id))?.accent || dominant.theme.accent || '#0a84ff');
    document.body.dataset.dominantEra = dominant.id;
    setText('[data-hero-subtitle]', heroLine(dominant, session));
    setText('[data-dominant-label]', `Estado dominante: ${dominant.label} · ${Math.round((session.vector[dominant.id] || 0) * 100)}%`);
    setText('[data-machine-summary]', dataset.parts.filter((part) => session.selectedParts.includes(part.id)).map((part) => part.summary).at(-1) || 'A máquina aguarda uma peça.');
    setText('[data-mechanism-copy]', `A montagem atual puxa o sistema visual para ${dominant.label.toLowerCase()} sem apagar rastros das outras eras.`);
    setText('[data-vector-readout]', JSON.stringify(session.vector, null, 2));
    setText('[data-state-summary]', `Sua linha: ${session.selectedParts.length} peça(s), ${session.selectedObjects.length} objeto(s), dominante ${dominant.label}.`);
    setText('[data-public-pulse]', `Sistema público: ${Math.round(Math.max(...Object.values(publicSnapshot.vector)) * 100)}% em ${getDominantEra(publicSnapshot.vector, dataset.eras).label}.`);
    renderBars(qs('[data-bars="individual"]'), session.vector, dataset.eras);
    renderBars(qs('[data-bars="public"]'), publicSnapshot.vector, dataset.eras);
    renderObjectList(dataset, session);
    renderCredentialState(session.credentialStatus);
    qsa('[data-toggle-tech]').forEach((button) => button.addEventListener('click', () => { const note = qs('[data-tech-note]'); const open = note.hasAttribute('hidden'); note.toggleAttribute('hidden', !open); button.setAttribute('aria-expanded', String(open)); }, { once: true }));
  }

  const machineCarousel = qs('[data-machine-carousel]');
  if (machineCarousel) createDetailCarousel(machineCarousel, dataset.parts, (part, user) => {
    const partImage = qs('[data-part-image]');
    if (partImage) partImage.src = assets[part.imageKey] || assets.mechanism;
    if (user && !session.selectedParts.includes(part.id)) {
      session = updateSession(session, dataset, { selectedParts: [...session.selectedParts, part.id].slice(-5) });
      persistAndRender();
    } else {
      renderAll();
    }
  });

  renderObjectList(dataset, session);
  if (!globalEventsBound) {
    bindEvents(dataset, () => session, (next) => { session = next; }, async () => { publicSnapshot = await refreshPublic(dataset); renderAll(); });
    globalEventsBound = true;
  }
  initAdminPanel({ dialog: qs('[data-admin-dialog]'), dataset, persistence: localPersistence, onRestore: () => location.reload() });
  qs('[data-open-admin]')?.addEventListener('click', () => qs('[data-admin-dialog]')?.showModal());

  await persistAndRender();
}

function setText(selector, value) {
  const element = qs(selector);
  if (element) element.textContent = value;
}

function hydrateAssetImages() {
  qsa('[data-asset-key]').forEach((image) => {
    const source = assets[image.dataset.assetKey];
    if (source && image.getAttribute('src') !== source) image.src = source;
  });
}

function renderObjectList(dataset, session) {
  const root = qs('[data-object-list]');
  if (!root) return;
  const dominant = getDominantEra(session.vector, dataset.eras);
  root.innerHTML = dataset.objects.map((object) => {
    const version = object.versions.find((item) => item.eraId === dominant.id) || object.versions[0];
    const selected = session.selectedObjects.includes(object.id);
    return `<article class="object-card ${selected ? 'is-selected' : ''}"><div class="object-thumb" data-slot="visual-object" data-object-id="${object.id}" data-era-id="${version.eraId}">${object.name.slice(0, 2)}</div><h3>${object.name}</h3><p>${object.function}</p><p><strong>${version.label}</strong></p><button type="button" data-toggle-object="${object.id}" aria-pressed="${selected}">${selected ? 'Remover' : 'Selecionar'}</button></article>`;
  }).join('');
}

function bindEvents(dataset, getSession, setSession, refresh) {
  document.addEventListener('click', async (event) => {
    if (event.target.closest('[data-credential-login]')) {
      const next = updateSession(getSession(), dataset, { credentialStatus: 'authenticated' });
      setSession(next);
      await localPersistence.saveCredentialStatus('authenticated');
      await localPersistence.saveSession(next);
      updateUrl(next);
      renderCredentialState('authenticated', { confirming: true });
      window.setTimeout(() => closeCredentialDialog({ keepReopen: false }), 780);
      return;
    }
    if (event.target.closest('[data-credential-dismiss]')) {
      const next = updateSession(getSession(), dataset, { credentialStatus: 'dismissed' });
      setSession(next);
      await localPersistence.saveCredentialStatus('dismissed');
      await localPersistence.saveSession(next);
      closeCredentialDialog({ keepReopen: true });
      return;
    }
    if (event.target.closest('[data-credential-reopen]')) {
      openCredentialDialog();
      return;
    }
    const toggle = event.target.closest('[data-toggle-object]');
    if (toggle) {
      const session = getSession(); const id = toggle.dataset.toggleObject;
      const selectedObjects = session.selectedObjects.includes(id) ? session.selectedObjects.filter((item) => item !== id) : [...session.selectedObjects, id];
      setSession(updateSession(session, dataset, { selectedObjects }));
      pulseNarrative('object');
      await localPersistence.saveSession(getSession()); updateUrl(getSession()); refresh();
    }
    if (event.target.closest('[data-complete-session]')) {
      setSession({ ...getSession(), completed: true, updatedAt: new Date().toISOString() });
      await localPersistence.saveSession(getSession()); await refresh();
    }
    if (event.target.closest('[data-reset-session]')) {
      setSession(createSession(dataset)); await localPersistence.saveSession(getSession()); updateUrl(getSession()); document.getElementById('machine')?.scrollIntoView({ behavior: 'smooth' }); await refresh();
    }
  });
}

async function refreshPublic(dataset) {
  const snapshot = createPublicSnapshot(await localPersistence.loadSessions(), dataset.eras);
  await localPersistence.savePublicSnapshot(snapshot);
  return snapshot;
}


function renderCredentialState(status, options = {}) {
  const dialog = qs('[data-credential-dialog]');
  const reopen = qs('[data-credential-reopen]');
  const timeline = qs('[data-individual-timeline]');
  const caption = qs('[data-credential-caption]');
  if (!dialog || !reopen || !timeline || !caption) return;
  timeline.classList.toggle('is-credential-authenticated', status === 'authenticated');
  if (options.confirming) {
    timeline.classList.add('is-confirming');
    window.setTimeout(() => timeline.classList.remove('is-confirming'), 820);
  }
  caption.textContent = status === 'authenticated' ? 'Acesso temporal restabelecido' : 'Interferência aguardando credenciais.';
  if (status === 'authenticated') {
    if (options.confirming) dialog.classList.add('is-visible'); else dialog.classList.remove('is-visible', 'is-closing');
    reopen.classList.remove('is-visible');
    return;
  }
  if (status === 'dismissed') {
    dialog.classList.remove('is-visible');
    reopen.classList.add('is-visible');
    return;
  }
  dialog.classList.add('is-visible');
  reopen.classList.remove('is-visible');
}

function openCredentialDialog() {
  qs('[data-credential-dialog]')?.classList.remove('is-closing');
  qs('[data-credential-dialog]')?.classList.add('is-visible');
  qs('[data-credential-reopen]')?.classList.remove('is-visible');
}

function closeCredentialDialog({ keepReopen }) {
  const dialog = qs('[data-credential-dialog]');
  const reopen = qs('[data-credential-reopen]');
  if (!dialog || !reopen) return;
  dialog.classList.add('is-closing');
  dialog.classList.remove('is-visible');
  window.setTimeout(() => {
    dialog.classList.remove('is-closing');
    reopen.classList.toggle('is-visible', keepReopen);
  }, 280);
}

function renderBars(root, vector, eras) {
  if (!root) return;
  root.innerHTML = eras.map((era) => `<div data-era="${era.id}"><span>${era.label}</span><i style="transform:scaleX(${vector[era.id] || 0})"></i><b>${Math.round((vector[era.id] || 0) * 100)}%</b></div>`).join('');
}

function heroLine(era, session) {
  const object = session.selectedObjects.at(-1) || 'forma';
  return era.id === 'past' ? `O ${object} lembra o bolo antes da chegada.` : era.id === 'future' ? `O ${object} chegou de uma fornada que ainda não aconteceu.` : `O ${object} mantém o presente aberto por alguns quadros.`;
}

function updateUrl(session) {
  const params = new URLSearchParams(location.search);
  params.set('parts', session.selectedParts.join(',')); params.set('objects', session.selectedObjects.join(','));
  history.replaceState(null, '', `${location.pathname}?${params.toString()}${location.hash}`);
}

function restoreFromUrl(dataset) {
  const params = new URLSearchParams(location.search);
  if (!params.has('parts') && !params.has('objects')) return null;
  const parts = (params.get('parts') || '').split(',').filter((id) => dataset.parts.some((part) => part.id === id));
  const objects = (params.get('objects') || '').split(',').filter((id) => dataset.objects.some((object) => object.id === id));
  return createSession(dataset, { parts: parts.length ? parts : ['sequence'], objects: objects.length ? objects : ['forma'] });
}

function initializeOnce() {
  if (!initializationPromise) {
    initializationPromise = boot().catch((error) => {
      initializationPromise = null;
      throw error;
    });
  }
  return initializationPromise;
}

function enableBasicMode(error) {
  console.error('[Experience] Falha na inicialização', {
    name: error?.name,
    message: error?.message,
    stack: error?.stack,
    cause: error?.cause,
    pathname: window.location.pathname
  });
  if (error instanceof ExperienceResourceError) {
    console.error('[Experience] Recurso essencial falhou', {
      resourceId: error.resourceId,
      resourceType: error.resourceType,
      url: error.url,
      status: error.status,
      statusText: error.statusText,
      contentType: error.contentType,
      error
    });
  }
  let alert = qs('[data-experience-fallback-alert]');
  if (!alert) {
    document.body.insertAdjacentHTML('afterbegin', '<p role="alert" data-experience-fallback-alert style="padding:1rem;background:#401;color:white">Não foi possível carregar uma parte essencial da experiência. Recarregue a página ou tente novamente em instantes. <button type="button" data-experience-retry>Tentar novamente</button></p>');
    alert = qs('[data-experience-fallback-alert]');
    qs('[data-experience-retry]', alert)?.addEventListener('click', () => {
      initializeOnce().then(() => alert?.remove()).catch(enableBasicMode);
    });
  }
}

initializeOnce().catch(enableBasicMode);


function initFloatingNarrative() {
  const flyer = qs('[data-floating-narrative]');
  const layer = flyer?.closest('.floating-narrative-layer');
  const destination = qs('[data-floating-destination="visual-system"]') || qs('#visual-system') || qs('.visual-system.section-shell.reveal');
  if (!flyer || !layer) {
    console.warn('[Floating guide] Elemento flutuante não encontrado.');
    return;
  }

  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const STATES = {
    ROAMING: 'ROAMING',
    EXITING_TO_DESTINATION: 'EXITING_TO_DESTINATION',
    SCROLLING_TO_DESTINATION: 'SCROLLING_TO_DESTINATION',
    ENTERING_DESTINATION: 'ENTERING_DESTINATION',
    ANCHORED_AT_DESTINATION: 'ANCHORED_AT_DESTINATION',
    EXITING_TO_ORIGIN: 'EXITING_TO_ORIGIN',
    SCROLLING_TO_ORIGIN: 'SCROLLING_TO_ORIGIN',
    ENTERING_ORIGIN: 'ENTERING_ORIGIN'
  };
  const state = { mode: STATES.ROAMING, busy: false, originSnapshot: null, lastPose: { x: 0, y: 0, rotation: -8, scale: 1 }, startTime: performance.now(), width: 0, height: 0, navigationEnabled: Boolean(destination) };

  const setA11y = (label, pressed = false, busy = false) => { flyer.alt = label; flyer.setAttribute('aria-label', label); flyer.setAttribute('aria-pressed', String(pressed)); flyer.toggleAttribute('aria-busy', busy); };
  const announce = (message) => { let live = qs('[data-floating-guide-live]'); if (!live) { document.body.insertAdjacentHTML('beforeend', '<span data-floating-guide-live class="sr-only" aria-live="polite"></span>'); live = qs('[data-floating-guide-live]'); } live.textContent = message; };
  const setPose = ({ x, y, rotation = -8, scale = 1, opacity = 0.88 }) => { state.lastPose = { x, y, rotation, scale }; flyer.style.setProperty('--narrative-x', `${x}px`); flyer.style.setProperty('--narrative-y', `${y}px`); flyer.style.setProperty('--narrative-rotation', `${rotation}deg`); flyer.style.setProperty('--narrative-scale', scale.toFixed(3)); flyer.style.opacity = opacity.toFixed(3); };
  const safeClamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const organicPose = (now) => {
    const maxScroll = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    const progress = scrollY / maxScroll;
    const box = flyer.getBoundingClientRect();
    const width = box.width || state.width || 160; const height = box.height || state.height || 160;
    state.width = width; state.height = height;
    const t = (now - state.startTime) / 1000; const mobile = matchMedia('(max-width: 767px)').matches;
    const baseX = mobile ? innerWidth * (0.62 + progress * 0.16) : innerWidth * (0.08 + progress * 0.64);
    const baseY = mobile ? innerHeight * (0.09 + progress * 0.78) : innerHeight * (0.14 + progress * 0.62);
    const driftX = Math.sin(t * 0.37) * innerWidth * 0.035 + Math.sin(t * 0.113 + 1.8) * innerWidth * 0.026;
    const driftY = Math.cos(t * 0.29 + 0.7) * innerHeight * 0.032 + Math.sin(t * 0.071) * innerHeight * 0.025;
    return { x: safeClamp(baseX + driftX, 12, innerWidth - width - 12), y: safeClamp(baseY + driftY, 12, innerHeight - height - 12), rotation: -6 + Math.sin(t * 0.23) * 7 + Math.cos(t * 0.097) * 3, scale: 1 + Math.sin(t * 0.17) * 0.025, opacity: mobile ? 0.62 : 0.88 };
  };
  const tick = (now) => { if (state.mode === STATES.ROAMING && !state.busy && !reduceMotion.matches) setPose(organicPose(now)); requestAnimationFrame(tick); };
  const animatePortal = (direction) => {
    if (reduceMotion.matches) { flyer.style.opacity = direction === 'out' ? '0' : '0.88'; return Promise.resolve(); }
    const sign = direction === 'out' ? 1 : -1; const duration = direction === 'out' ? 640 : 720;
    const opacity = direction === 'out' ? [0.88, 0.66, 0] : [0, 0.64, 0.88]; const scale = direction === 'out' ? [1, 0.72, 0.18] : [0.18, 0.72, 1];
    return flyer.animate([{ transform: `translate3d(var(--narrative-x),var(--narrative-y),0) translate(0,0) rotate(${state.lastPose.rotation}deg) scale(${scale[0]})`, opacity: opacity[0] }, { transform: `translate3d(var(--narrative-x),var(--narrative-y),0) translate(${18 * sign}px,${-16 * sign}px) rotate(${state.lastPose.rotation + 115 * sign}deg) scale(${scale[1]})`, opacity: opacity[1], offset: 0.58 }, { transform: `translate3d(var(--narrative-x),var(--narrative-y),0) translate(0,0) rotate(${state.lastPose.rotation + 360 * sign}deg) scale(${scale[2]})`, opacity: opacity[2] }], { duration, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'forwards' }).finished;
  };
  const getDestinationScrollTarget = (element) => { const header = qs('[data-site-header]') || qs('header'); const headerHeight = header?.getBoundingClientRect().height || 0; return Math.max(0, element.getBoundingClientRect().top + scrollY - headerHeight - 24); };
  const waitForScrollEnd = (targetY) => new Promise((resolve) => {
    let resolved = false;
    const done = () => { if (resolved) return; resolved = true; window.removeEventListener('scrollend', done); resolve(); };
    if ('onscrollend' in window) window.addEventListener('scrollend', done, { once: true });
    let stable = 0;
    const check = () => {
      if (resolved) return;
      stable = Math.abs(scrollY - targetY) <= 2 ? stable + 1 : 0;
      if (stable > 4) done(); else requestAnimationFrame(check);
    };
    check();
  });
  const scrollToY = async (top) => { scrollTo({ top, left: 0, behavior: reduceMotion.matches ? 'auto' : 'smooth' }); await waitForScrollEnd(top); };
  const destinationPose = () => { const anchor = qs('[data-floating-guide-destination-anchor]', destination) || destination; const rect = anchor.getBoundingClientRect(); const box = flyer.getBoundingClientRect(); return { x: safeClamp(rect.left - box.width / 2, 12, innerWidth - box.width - 12), y: safeClamp(rect.top - box.height / 2, 12, innerHeight - box.height - 12), rotation: -4, scale: 0.92, opacity: 0.9 }; };
  const restoreSafe = () => { setPose(organicPose(performance.now())); setA11y('Ir para o sistema visual'); layer.classList.remove('is-transitioning'); state.busy = false; state.mode = STATES.ROAMING; };
  const travelToDestination = async () => {
    state.originSnapshot = { scrollX, scrollY, viewportWidth: innerWidth, viewportHeight: innerHeight, guideRect: flyer.getBoundingClientRect(), timestamp: Date.now() };
    state.mode = STATES.EXITING_TO_DESTINATION; setA11y('Indo para o sistema visual', false, true); await animatePortal('out');
    state.mode = STATES.SCROLLING_TO_DESTINATION; await scrollToY(getDestinationScrollTarget(destination));
    state.mode = STATES.ENTERING_DESTINATION; setPose(destinationPose()); await animatePortal('in');
    state.mode = STATES.ANCHORED_AT_DESTINATION; layer.classList.add('is-docked'); setA11y('Voltar ao ponto anterior da página', true); announce('Sistema visual alcançado.');
    window.dispatchEvent(new CustomEvent('floating-guide-travel-to-visual-system'));
  };
  const returnToOrigin = async () => {
    const snapshot = state.originSnapshot; state.mode = STATES.EXITING_TO_ORIGIN; setA11y('Indo para o sistema visual', true, true); await animatePortal('out');
    state.mode = STATES.SCROLLING_TO_ORIGIN; await scrollToY(snapshot.scrollY); window.scrollTo({ top: snapshot.scrollY, left: snapshot.scrollX, behavior: 'auto' });
    state.mode = STATES.ENTERING_ORIGIN; setPose({ x: snapshot.guideRect.left, y: snapshot.guideRect.top, rotation: state.lastPose.rotation, scale: state.lastPose.scale, opacity: 0.88 }); await animatePortal('in');
    state.mode = STATES.ROAMING; layer.classList.remove('is-docked'); setA11y('Ir para o sistema visual'); announce('Retorno ao ponto anterior concluído.'); state.originSnapshot = null;
    window.dispatchEvent(new CustomEvent('floating-guide-return-to-origin'));
  };
  const jump = async () => {
    if (state.busy || !state.navigationEnabled) return;
    state.busy = true; layer.classList.add('is-transitioning');
    try { if (state.mode === STATES.ANCHORED_AT_DESTINATION) await returnToOrigin(); else await travelToDestination(); }
    catch (error) { console.error('[Floating guide] Falha na navegação do elemento flutuante.', error); restoreSafe(); }
    finally { flyer.removeAttribute('aria-busy'); layer.classList.remove('is-transitioning'); state.busy = false; }
  };
  if (!destination) { console.error('[Floating guide] A seção de destino não foi encontrada.'); state.navigationEnabled = false; setA11y('Ir para o sistema visual'); }
  flyer.addEventListener('click', jump);
  flyer.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); jump(); } });
  addEventListener('resize', () => { if (state.mode === STATES.ANCHORED_AT_DESTINATION && destination) setPose(destinationPose()); });
  setA11y('Ir para o sistema visual'); if (reduceMotion.matches) setPose({ x: Math.max(12, innerWidth - 140), y: 96, rotation: -6, scale: 1, opacity: 0.72 });
  requestAnimationFrame(tick);
}

function pulseNarrative(reason = 'state') {
  document.body.dataset.narrativePulse = reason;
  window.clearTimeout(pulseNarrative.timer);
  pulseNarrative.timer = window.setTimeout(() => { delete document.body.dataset.narrativePulse; }, 900);
}